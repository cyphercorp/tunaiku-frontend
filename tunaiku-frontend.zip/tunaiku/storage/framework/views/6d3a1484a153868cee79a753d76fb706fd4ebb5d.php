<!DOCTYPE html>
<html>
<title>Tunaiku.com</title>
<head>
<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="<?php echo asset('css/materialize.min.css'); ?>"  media="screen,projection"/>
<link type="text/css" rel="stylesheet" href="<?php echo asset('css/style.css'); ?>"  media="screen,projection"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>